﻿using ClassLibraryFürjes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibraryFürjes
{
    public class ClassFurj
    {
        public int Sorszam { get; private set; }
        public string Fajta { get; private set; }
        public int TojikE { get; private set; }
        public int Eletkor { get; private set; }
        public static List<ClassFurj> FürjekLista = new List<ClassFurj>();
        public ClassFurj(string sor)
        {
            string[] db = sor.Split(';');

            this.Sorszam = int.Parse(db[0]);
            this.Fajta = db[1];
            this.TojikE = int.Parse(db[2]);
            this.Eletkor = int.Parse(db[3]);

            FürjekLista.Add(this);

        }

    }
}
