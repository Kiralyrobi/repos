﻿namespace Fürj
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.groupBoxFurjekSorszama = new System.Windows.Forms.GroupBox();
            this.buttonFurjHozzaadas = new System.Windows.Forms.Button();
            this.textBoxFurjekSorszama = new System.Windows.Forms.TextBox();
            this.labelFurjekSorszama = new System.Windows.Forms.Label();
            this.groupBoxKozos = new System.Windows.Forms.GroupBox();
            this.groupBoxFaj = new System.Windows.Forms.GroupBox();
            this.textBoxFaj = new System.Windows.Forms.TextBox();
            this.labelFaj = new System.Windows.Forms.Label();
            this.groupBoxEletkor = new System.Windows.Forms.GroupBox();
            this.textBoxEletkor = new System.Windows.Forms.TextBox();
            this.labelEletkor = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radioButtonNem = new System.Windows.Forms.RadioButton();
            this.radioButtonIgen = new System.Windows.Forms.RadioButton();
            this.labeltojikE = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.buttonFurjekListaja = new System.Windows.Forms.Button();
            this.FurjekListaja = new System.Windows.Forms.ListBox();
            this.buttonHozzaad = new System.Windows.Forms.Button();
            this.groupBoxFurjekSorszama.SuspendLayout();
            this.groupBoxKozos.SuspendLayout();
            this.groupBoxFaj.SuspendLayout();
            this.groupBoxEletkor.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBoxFurjekSorszama
            // 
            this.groupBoxFurjekSorszama.Controls.Add(this.buttonFurjHozzaadas);
            this.groupBoxFurjekSorszama.Controls.Add(this.textBoxFurjekSorszama);
            this.groupBoxFurjekSorszama.Controls.Add(this.labelFurjekSorszama);
            this.groupBoxFurjekSorszama.Location = new System.Drawing.Point(6, 33);
            this.groupBoxFurjekSorszama.Name = "groupBoxFurjekSorszama";
            this.groupBoxFurjekSorszama.Size = new System.Drawing.Size(235, 102);
            this.groupBoxFurjekSorszama.TabIndex = 3;
            this.groupBoxFurjekSorszama.TabStop = false;
            this.groupBoxFurjekSorszama.Text = "Fürj sorszáma";
            // 
            // buttonFurjHozzaadas
            // 
            this.buttonFurjHozzaadas.Location = new System.Drawing.Point(154, 73);
            this.buttonFurjHozzaadas.Name = "buttonFurjHozzaadas";
            this.buttonFurjHozzaadas.Size = new System.Drawing.Size(75, 23);
            this.buttonFurjHozzaadas.TabIndex = 5;
            this.buttonFurjHozzaadas.Text = "Hozzáadás";
            this.buttonFurjHozzaadas.UseVisualStyleBackColor = true;
            // 
            // textBoxFurjekSorszama
            // 
            this.textBoxFurjekSorszama.Location = new System.Drawing.Point(97, 50);
            this.textBoxFurjekSorszama.Name = "textBoxFurjekSorszama";
            this.textBoxFurjekSorszama.Size = new System.Drawing.Size(100, 20);
            this.textBoxFurjekSorszama.TabIndex = 1;
            // 
            // labelFurjekSorszama
            // 
            this.labelFurjekSorszama.AutoSize = true;
            this.labelFurjekSorszama.Location = new System.Drawing.Point(6, 53);
            this.labelFurjekSorszama.Name = "labelFurjekSorszama";
            this.labelFurjekSorszama.Size = new System.Drawing.Size(86, 13);
            this.labelFurjekSorszama.TabIndex = 0;
            this.labelFurjekSorszama.Text = "Fürjek sorszáma:";
            // 
            // groupBoxKozos
            // 
            this.groupBoxKozos.Controls.Add(this.buttonHozzaad);
            this.groupBoxKozos.Controls.Add(this.groupBoxFaj);
            this.groupBoxKozos.Controls.Add(this.groupBoxEletkor);
            this.groupBoxKozos.Controls.Add(this.groupBox1);
            this.groupBoxKozos.Controls.Add(this.groupBoxFurjekSorszama);
            this.groupBoxKozos.Location = new System.Drawing.Point(23, 90);
            this.groupBoxKozos.Name = "groupBoxKozos";
            this.groupBoxKozos.Size = new System.Drawing.Size(499, 326);
            this.groupBoxKozos.TabIndex = 4;
            this.groupBoxKozos.TabStop = false;
            this.groupBoxKozos.Text = "Fürj és tojás";
            this.groupBoxKozos.Visible = false;
            // 
            // groupBoxFaj
            // 
            this.groupBoxFaj.Controls.Add(this.textBoxFaj);
            this.groupBoxFaj.Controls.Add(this.labelFaj);
            this.groupBoxFaj.Location = new System.Drawing.Point(258, 33);
            this.groupBoxFaj.Name = "groupBoxFaj";
            this.groupBoxFaj.Size = new System.Drawing.Size(233, 102);
            this.groupBoxFaj.TabIndex = 6;
            this.groupBoxFaj.TabStop = false;
            this.groupBoxFaj.Text = "Fürj fajtája";
            // 
            // textBoxFaj
            // 
            this.textBoxFaj.Location = new System.Drawing.Point(93, 48);
            this.textBoxFaj.Name = "textBoxFaj";
            this.textBoxFaj.Size = new System.Drawing.Size(100, 20);
            this.textBoxFaj.TabIndex = 1;
            // 
            // labelFaj
            // 
            this.labelFaj.AutoSize = true;
            this.labelFaj.Location = new System.Drawing.Point(29, 51);
            this.labelFaj.Name = "labelFaj";
            this.labelFaj.Size = new System.Drawing.Size(58, 13);
            this.labelFaj.TabIndex = 0;
            this.labelFaj.Text = "Fürj fajtája:";
            // 
            // groupBoxEletkor
            // 
            this.groupBoxEletkor.Controls.Add(this.textBoxEletkor);
            this.groupBoxEletkor.Controls.Add(this.labelEletkor);
            this.groupBoxEletkor.Location = new System.Drawing.Point(258, 151);
            this.groupBoxEletkor.Name = "groupBoxEletkor";
            this.groupBoxEletkor.Size = new System.Drawing.Size(234, 101);
            this.groupBoxEletkor.TabIndex = 5;
            this.groupBoxEletkor.TabStop = false;
            this.groupBoxEletkor.Text = "Életkor";
            // 
            // textBoxEletkor
            // 
            this.textBoxEletkor.Location = new System.Drawing.Point(67, 61);
            this.textBoxEletkor.Name = "textBoxEletkor";
            this.textBoxEletkor.Size = new System.Drawing.Size(80, 20);
            this.textBoxEletkor.TabIndex = 1;
            // 
            // labelEletkor
            // 
            this.labelEletkor.AutoSize = true;
            this.labelEletkor.Location = new System.Drawing.Point(55, 45);
            this.labelEletkor.Name = "labelEletkor";
            this.labelEletkor.Size = new System.Drawing.Size(108, 13);
            this.labelEletkor.TabIndex = 0;
            this.labelEletkor.Text = "Hány hónapos a fürj?";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radioButtonNem);
            this.groupBox1.Controls.Add(this.radioButtonIgen);
            this.groupBox1.Controls.Add(this.labeltojikE);
            this.groupBox1.Location = new System.Drawing.Point(6, 151);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(235, 102);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Tojik-e?";
            // 
            // radioButtonNem
            // 
            this.radioButtonNem.AutoSize = true;
            this.radioButtonNem.Location = new System.Drawing.Point(119, 80);
            this.radioButtonNem.Name = "radioButtonNem";
            this.radioButtonNem.Size = new System.Drawing.Size(45, 17);
            this.radioButtonNem.TabIndex = 2;
            this.radioButtonNem.TabStop = true;
            this.radioButtonNem.Text = "nem";
            this.radioButtonNem.UseVisualStyleBackColor = true;
            // 
            // radioButtonIgen
            // 
            this.radioButtonIgen.AutoSize = true;
            this.radioButtonIgen.Location = new System.Drawing.Point(48, 78);
            this.radioButtonIgen.Name = "radioButtonIgen";
            this.radioButtonIgen.Size = new System.Drawing.Size(45, 17);
            this.radioButtonIgen.TabIndex = 1;
            this.radioButtonIgen.TabStop = true;
            this.radioButtonIgen.Text = "igen";
            this.radioButtonIgen.UseVisualStyleBackColor = true;
            // 
            // labeltojikE
            // 
            this.labeltojikE.AutoSize = true;
            this.labeltojikE.Location = new System.Drawing.Point(66, 35);
            this.labeltojikE.Name = "labeltojikE";
            this.labeltojikE.Size = new System.Drawing.Size(71, 13);
            this.labeltojikE.TabIndex = 0;
            this.labeltojikE.Text = "Tojik-e a fürj?";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(183, 60);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(156, 24);
            this.button1.TabIndex = 5;
            this.button1.Text = "Új fürj bevitel";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // buttonFurjekListaja
            // 
            this.buttonFurjekListaja.Location = new System.Drawing.Point(599, 60);
            this.buttonFurjekListaja.Name = "buttonFurjekListaja";
            this.buttonFurjekListaja.Size = new System.Drawing.Size(155, 24);
            this.buttonFurjekListaja.TabIndex = 6;
            this.buttonFurjekListaja.Text = "Fürjek listája";
            this.buttonFurjekListaja.UseVisualStyleBackColor = true;
            this.buttonFurjekListaja.Click += new System.EventHandler(this.buttonFurjekListaja_Click);
            // 
            // FurjekListaja
            // 
            this.FurjekListaja.FormattingEnabled = true;
            this.FurjekListaja.Location = new System.Drawing.Point(580, 93);
            this.FurjekListaja.Name = "FurjekListaja";
            this.FurjekListaja.Size = new System.Drawing.Size(203, 277);
            this.FurjekListaja.TabIndex = 7;
            this.FurjekListaja.Visible = false;
            // 
            // buttonHozzaad
            // 
            this.buttonHozzaad.Location = new System.Drawing.Point(87, 275);
            this.buttonHozzaad.Name = "buttonHozzaad";
            this.buttonHozzaad.Size = new System.Drawing.Size(318, 33);
            this.buttonHozzaad.TabIndex = 7;
            this.buttonHozzaad.Text = "Adatok hozzáadása";
            this.buttonHozzaad.UseVisualStyleBackColor = true;
            this.buttonHozzaad.Click += new System.EventHandler(this.buttonHozzaad_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(846, 507);
            this.Controls.Add(this.FurjekListaja);
            this.Controls.Add(this.buttonFurjekListaja);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBoxKozos);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBoxFurjekSorszama.ResumeLayout(false);
            this.groupBoxFurjekSorszama.PerformLayout();
            this.groupBoxKozos.ResumeLayout(false);
            this.groupBoxFaj.ResumeLayout(false);
            this.groupBoxFaj.PerformLayout();
            this.groupBoxEletkor.ResumeLayout(false);
            this.groupBoxEletkor.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBoxFurjekSorszama;
        private System.Windows.Forms.Button buttonFurjHozzaadas;
        private System.Windows.Forms.TextBox textBoxFurjekSorszama;
        private System.Windows.Forms.Label labelFurjekSorszama;
        private System.Windows.Forms.GroupBox groupBoxKozos;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radioButtonNem;
        private System.Windows.Forms.RadioButton radioButtonIgen;
        private System.Windows.Forms.Label labeltojikE;
        private System.Windows.Forms.GroupBox groupBoxEletkor;
        private System.Windows.Forms.TextBox textBoxEletkor;
        private System.Windows.Forms.Label labelEletkor;
        private System.Windows.Forms.GroupBox groupBoxFaj;
        private System.Windows.Forms.TextBox textBoxFaj;
        private System.Windows.Forms.Label labelFaj;
        private System.Windows.Forms.Button buttonFurjekListaja;
        private System.Windows.Forms.ListBox FurjekListaja;
        private System.Windows.Forms.Button buttonHozzaad;
    }
}

