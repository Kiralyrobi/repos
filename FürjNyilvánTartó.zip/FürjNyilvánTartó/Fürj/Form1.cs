﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Fürj
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (button1.Text == "Új fürj bevitel")
            {
                groupBoxKozos.Visible = true;
                button1.Text = "Vissza";
                buttonFurjekListaja.Visible = false;
                FurjekListaja.Visible=false;
            }
            else
            {
                groupBoxKozos.Visible=false;
                button1.Text = "Új fürj bevitel";
                buttonFurjekListaja.Visible = true;
                FurjekListaja.Visible = false;
                buttonFurjekListaja.Text = "Fürjek listája";
            }
        }

        private void buttonFurjekListaja_Click(object sender, EventArgs e)
        {
            if(buttonFurjekListaja.Text=="Fürjek listája")
            {
                FurjekListaja.Visible = true;
                buttonFurjekListaja.Text = "Vissza";
            }
            else
            {
                FurjekListaja.Visible=false;
                buttonFurjekListaja.Text = "Fürjek listája";
            }
        }

        private void buttonHozzaad_Click(object sender, EventArgs e)
        {

        }
    }
}
